package com.rabiakaynar.kriptopara.service;

import com.rabiakaynar.kriptopara.model.CryptoModel;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface CryptoAPI {

    @GET("prices?key=1313abe6dcc715b79a83fbe88218cf89")
    Call<List<CryptoModel>> getData();

}
